(function() {

if (! UXES.fileio) {
    UXES.fileio = {};
}

// Symbolic constants for text file IO functions

UXES.fileio.FILEIO_APPEND_NEWLINE = "APPEND_NL";
UXES.fileio.FILEIO_DONT_APPEND_NEWLINE = "DONT_APPEND_NL";

})();
