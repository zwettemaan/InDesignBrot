UXES.C.DIRNAME_PREFERENCES  = "InDesignBrot";
UXES.C.FILENAME_PREFERENCES = "UXPScriptSparkerPreferences.json";

UXES.C.LOG_NONE                      = 0;
UXES.C.LOG_ERROR                     = 1;
UXES.C.LOG_WARN                      = 2;
UXES.C.LOG_WARNING                   = UXES.C.LOG_WARN;
UXES.C.LOG_NOTE                      = 3;
UXES.C.LOG_TRACE                     = 4;

/* Add any global constants */
