// Function mapAppId(): convert short app code to readable app name 
// Auto-generated from appMap.json data

UXES.mapAppId = function mapAppId(appId) {var retVal;switch (appId) {case "AICY":retVal = "InCopy";break;case "IDSN":retVal = "InDesign";break;}return retVal;}
