UXES.C.HOST                 = '0.0.0.0';
UXES.C.PORT                 = 8080;

